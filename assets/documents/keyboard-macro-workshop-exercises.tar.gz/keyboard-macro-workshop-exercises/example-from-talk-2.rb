class Product < ActiveRecord::Base
  def product_info
    if name == 'Pancakes'
      {
        'amazon_id' => '234hc349',
        'tasty rating' => 9.9,
        'price' => 100,
        'do a lot of people like to eat this at breakfast' => true
      }
    elsif name == 'Hot potato'
      {
        'amazon_id' => '29311aac2',
        'tasty rating' => 7.5,
        'price' => 1.3,
        'do a lot of people like to eat this at breakfast' => false
      }
    elsif name == 'Blueberry muffins'
      {
        'amazon_id' => '28es/=ahe',
        'tasty rating' => 8.3,
        'price' => 32,
        'do a lot of people like to eat this at breakfast' => true
      }
    elsif name == 'Beachball'
      {
        'amazon_id' => '9eohe8es',
        'tasty rating' => 0.2,
        'price' => 12,
        'do a lot of people like to eat this at breakfast' => false
      }
    elsif name == 'Chicken sauce'
      {
        'amazon_id' => '293_383a',
        'tasty rating' => 3.7,
        'price' => 22,
        'do a lot of people like to eat this at breakfast' => false
      }
    elsif name == 'Insurance'
      {
        'amazon_id' => '7eeu8eeo',
        'tasty rating' => 0.0,
        'price' => 1000000,
        'do a lot of people like to eat this at breakfast' => false
      }
    elsif name == 'Nutella'
      {
        'amazon_id' => '48e34to5',
        'tasty rating' => 10,
        'price' => 5,
        'do a lot of people like to eat this at breakfast' => true
      }
    end
  end
end
