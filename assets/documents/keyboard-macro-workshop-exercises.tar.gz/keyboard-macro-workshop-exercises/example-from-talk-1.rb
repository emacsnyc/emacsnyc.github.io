class HoneyPieShop
  def initialize
    @items = {
      honey: 'http://example.com/images/',
      pie:  'http://example.com/images/',
      berries: 'http://example.com/images/',
      chocolate: 'http://example.com/images/', 
      smoothies: 'http://example.com/images/',
      baby_smoothies: 'http://example.com/images/',
      yummy_taco: 'http://example.com/images/',
    }
  end
end
