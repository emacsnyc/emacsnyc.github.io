<pre>
Generate a list of sql statements with an incrementing id starting at 1,
the username as a lowercase token of the full name (Trevor Colon -> trevor_colon)
the state
and the name

Example:
INSERT INTO users (id, username, state, name) VALUES (1, 'trevor_colon', 'Alabama', 'Trevor Colon');
INSERT INTO users (id, username, state, name) VALUES (2, 'clifton_ramsey', 'Hawaii', 'Clifton Ramsey');

Commands to practice:
C-x C-k C-i - kmacro-insert-counter
C-x C-k C-c - kmacro-set-counter
C-x C-k C-a - kmacro-add-counter

downcase-region


INSERT INTO users (id, username, state, name) VALUES ();

Trevor Colon
Clifton Ramsey
Jimmie Soto
Faye Nguyen
Samuel Carter
Willis Snyder
Charlotte Summers
Beverly Strickland
Danny Fields
Harry Lopez
Rhonda Hayes
Marguerite Conner
Rex Olson
Wilma Richards
Van Holland
Edna Moss
Heidi Owen
Carla Simon
Maggie Page
Tom Waters
Roxanne Armstrong
Yolanda Simpson
Johnnie Nichols
Cameron Smith
Marcia Kennedy


Trevor Colon is from Alabama.
Clifton Ramsey is from Hawaii.
Jimmie Soto is from Massachusetts.
Faye Nguyen is from New Mexico.
Samuel Carter is from South Dakota.
Willis Snyder is from Alaska.
Charlotte Summers is from Idaho.
Beverly Strickland is from Michigan.
Danny Fields is from New York.
Harry Lopez is from Tennessee.
Rhonda Hayes is from Arizona.
Marguerite Conner is from Illinois.
Rex Olson is from Minnesota.
Wilma Richards is from North Carolina.
Van Holland is from Texas.
Edna Moss is from Arkansas.
Heidi Owen is from Indiana.
Carla Simon is from Mississippi.
Maggie Page is from North Dakota.
Tom Waters is from Utah.
Roxanne Armstrong is from California.
Yolanda Simpson is from Iowa.
Johnnie Nichols is from Missouri.
Cameron Smith is from Ohio.
Marcia Kennedy is from Vermont.
</pre>
